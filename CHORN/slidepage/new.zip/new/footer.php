<link rel="stylesheet" href="FOOTER.css" />

<div class="navigation">
    <ul>
        <li class="list active">
            <a href="#home">
                <span class="icon">
                    <ion-icon name="home"></ion-icon>
                </span>
                <span class="text">Home</span>
                <span class="circle"></span>
            </a>
        </li>
        <li class="list">
            <a href="#2">
                <span class="icon">
                    <ion-icon name="people"></ion-icon>
                </span>
                <span class="text">MyGroup</span>
                <span class="circle"></span>
            </a>
        </li>
        <li class="list">
            <a href="#3">
                <span class="icon">
                    <ion-icon name="settings"></ion-icon>
                </span>
                <span class="text">Setting</span>
                <span class="circle"></span>
            </a>
        </li>
        <div class="indicator"></div>
    </ul>
</div>
<script>
    const list = document.querySelectorAll('.list');


    function activeLink() {
        list.forEach((item) =>
            item.classList.remove('active'));
        this.classList.add('active');
    }


    list.forEach((item) =>
        item.addEventListener('click', activeLink));
</script>

<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<!-- <script src="../js/script.js"></script> -->