<link rel="stylesheet" href="HEADER.css" />

<div class="HEADER"></div>
<img class="app-icon" alt="" src="../images/LOGO.svg" />

<div class="name-header">HOME</div>
<div class="LINE"></div>
<div class="noti-button-icon">
    <a href="#noti">
        <ion-icon name="notifications"></ion-icon>
    </a>
</div>
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>